/*
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @file src/chassis/leg_vmc.cpp
 * @ingroup wbr_modules
 * @brief 实现腿部虚拟模型控制的力矩映射。
 * @details 由主机控制线程按冻结输入调用；硬件采集和执行器输出通过显式接口提供。
 */

#include "leg_vmc.h"

#include <Eigen/Core>
#include <algorithm>

#include "chassis_config.h"

namespace {
// 本模块使用的固定算法参数，调整时与对应控制逻辑一起审查。
constexpr double kRetractFeedforward = 10.0;
constexpr double kRetractFeedforwardDeadband = 0.003;
constexpr double kExtendVelocityFeedforward = 60.0;
constexpr double kVelocityFeedforwardDeadband = 0.005;
}  // namespace

namespace {

using namespace dust_control::chassis::chassis_config;

}  // namespace

namespace dust_control::chassis {

double UpdateLegLengthIntegral(double integral_force, double length_error,
                               double dt, const ChassisConfig& config) {
    return std::clamp(integral_force + config.leg_length_ki * length_error * dt,
                      -config.integral_force_limit,
                      config.integral_force_limit);
}

LegVmcOutput ComputeLegVmc(const LegKinematics& leg, double target_leg_length,
                           double support_feedforward, double integral_force,
                           double leg_angle_torque, double filtered_leg_speed,
                           double target_leg_length_rate,
                           const ChassisConfig& config) {
    const double length_error = target_leg_length - leg.length;
    const double retract_feedforward =
        length_error < -kRetractFeedforwardDeadband ? -kRetractFeedforward
                                                    : 0.0;
    const double velocity_feedforward =
        target_leg_length_rate > kVelocityFeedforwardDeadband
            ? kExtendVelocityFeedforward * target_leg_length_rate
            : 0.0;

    LegVmcOutput output = {};
    output.axial_force = std::clamp(
        config.leg_length_kp * length_error -
            config.leg_length_kd * filtered_leg_speed + support_feedforward +
            integral_force + retract_feedforward + velocity_feedforward,
        -config.force_limit, config.force_limit);
    const double radial_x = leg.hx / leg.length;
    const double radial_z = leg.hz / leg.length;
    const double tangential_force = leg_angle_torque / leg.length;
    // 轴向力与切向力合成末端力 F，再经雅可比转置映射到关节力矩：tau = J^T F。
    const Eigen::Vector2d radial(radial_x, radial_z);
    const Eigen::Vector2d tangential(-radial_z, radial_x);
    const Eigen::Vector2d force =
        output.axial_force * radial + tangential_force * tangential;
    Eigen::Matrix2d J;
    J << leg.jacobian[0][0], leg.jacobian[0][1], leg.jacobian[1][0],
        leg.jacobian[1][1];
    const Eigen::Vector2d tau = J.transpose() * force;
    output.phi1_torque = tau[0];
    output.phi2_torque = tau[1];
    return output;
}

}  // namespace dust_control::chassis
