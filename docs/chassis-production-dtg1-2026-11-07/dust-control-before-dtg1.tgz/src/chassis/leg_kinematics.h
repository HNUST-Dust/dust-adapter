/**
 * @file src/chassis/leg_kinematics.h
 * @ingroup wbr_modules
 * @brief 实现五连杆腿部的正逆运动学与雅可比计算。
 * @details 由控制线程同步调用，不创建线程或执行设备 I/O。
 */

#pragma once
#include "chassis_config.h"

namespace dust_control::chassis {

/** @brief 五连杆腿部末端位姿、速度和雅可比矩阵。 */
struct LegKinematics {
    double hx = 0.0;  ///< 足端相对髋部的水平坐标，单位为米。
    double hz = 0.0;  ///< 足端相对髋部的竖直坐标，单位为米。
    double length = 0.0;       ///< 等效腿长，单位为米。
    double length_rate = 0.0;  ///< 等效腿长变化率，单位为米每秒。
    double angle = 0.0;        ///< 腿部或关节角度，单位为弧度。
    double angle_rate = 0.0;   ///< 角速度，单位为弧度每秒。
    /** @brief 关节角速度到足端平面速度的 2×2 雅可比矩阵。 */
    double jacobian[2][2] = {};
};

/**
 * @brief 由两个电机反馈角求解腿部末端位置，内部统一应用安装零偏。
 * @param phi1 D 电机角（未加安装零偏），单位为弧度。
 * @param phi2 B 电机角（未加安装零偏），单位为弧度。
 * @param branch 五连杆装配支路标识。
 * @param[out] hx 足端相对髋部的水平坐标。
 * @param[out] hz 足端相对髋部的竖直坐标。
 * @return 几何解有效时返回 `true`，否则返回 `false`。
 */
bool ForwardKinematics(double phi1, double phi2, int branch, double &hx,
                       double &hz, const ChassisConfig &config = {});
/**
 * @brief 由目标末端位置求解连续的关节角。
 *
 * 调用方应传入未加安装零偏的当前电机角作为迭代初值；输出仍为电机角。
 * 迭代通过公共正解应用安装零偏，调用方不能重复加减零偏。
 *
 * @param target_hx 目标足端水平坐标。
 * @param target_hz 目标足端竖直坐标。
 * @param branch 五连杆装配支路标识。
 * @param seed_phi1 D 电机角的迭代初值。
 * @param seed_phi2 B 电机角的迭代初值。
 * @param[out] phi1 求解得到的 D 电机目标角（未加安装零偏）。
 * @param[out] phi2 求解得到的 B 电机目标角（未加安装零偏）。
 * @return 迭代收敛且几何解有效时返回 `true`。
 */
bool InverseKinematics(double target_hx, double target_hz, int branch,
                       double seed_phi1, double seed_phi2, double &phi1,
                       double &phi2, const ChassisConfig &config = {});
/**
 * @brief 数值计算关节角到末端位置的雅可比矩阵。
 * @param phi1 D 电机角（未加安装零偏），单位为弧度。
 * @param phi2 B 电机角（未加安装零偏），单位为弧度。
 * @param branch 五连杆装配支路标识。
 * @param[out] jacobian 输出的 2×2 雅可比矩阵。
 * @return 矩阵计算成功时返回 `true`。
 */
bool NumericalJacobian(double phi1, double phi2, int branch,
                       double jacobian[2][2], const ChassisConfig &config = {});
/**
 * @brief 计算腿部末端位置、速度和雅可比矩阵。
 * @param phi1 D 电机角（未加安装零偏），单位为弧度。
 * @param phi2 B 电机角（未加安装零偏），单位为弧度。
 * @param dphi1 第一主动关节角速度，单位为弧度每秒。
 * @param dphi2 第二主动关节角速度，单位为弧度每秒。
 * @param branch 五连杆装配支路标识。
 * @param[out] leg 输出的腿部运动学状态。
 * @return 全部运动学量有效时返回 `true`。
 */
bool ComputeLegKinematics(double phi1, double phi2, double dphi1, double dphi2,
                          int branch, LegKinematics &leg,
                          const ChassisConfig &config = {});
}  // namespace dust_control::chassis
