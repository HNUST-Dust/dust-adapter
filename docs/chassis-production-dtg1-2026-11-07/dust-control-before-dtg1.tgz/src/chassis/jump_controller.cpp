/* SPDX-License-Identifier: Apache-2.0 */
#include "jump_controller.h"

#include <algorithm>
#include <cmath>

#include "chassis_config.h"
#include "leg_vmc.h"
#include "unified_lqr_schedule.h"

namespace {
// 本模块使用的固定算法参数，调整时与对应控制逻辑一起审查。
constexpr double kJumpPrecompressLegLength = 0.15;
constexpr double kJumpPrecompressLengthTolerance = 0.01;
constexpr double kJumpPrecompressSpeedTolerance = 0.2;
constexpr uint32_t kJumpPrecompressTimeoutMs = 200;
constexpr double kJumpJointBThrustSign = 1;
constexpr double kJumpJointDThrustSign = -1;
constexpr double kJumpThrustExitLegLength = 0.33;
constexpr uint32_t kJumpThrustTimeoutMs = 300;
constexpr double kJumpAirRetractLegLength = 0.16;
constexpr double kJumpAirRetractRate = 2.5;
constexpr double kJumpAirRetractGravityFeedforward = -12.0;
constexpr double kJumpAirRetractLengthTolerance = 0.01;
constexpr uint32_t kJumpAirRetractHoldMs = 100;
constexpr uint32_t kJumpAirRetractTimeoutMs = 500;
constexpr uint32_t kJumpTotalTimeoutMs = 2000;
}  // namespace

namespace dust_control::chassis {
namespace {
using namespace chassis_config;
constexpr size_t kStateCount = 10U;
constexpr size_t kOutputCount = 4U;
constexpr size_t kLeftTheta = 4U;
constexpr size_t kLeftThetaRate = 5U;
constexpr size_t kRightTheta = 6U;
constexpr size_t kRightThetaRate = 7U;
constexpr size_t kLeftWheel = 0U;
constexpr size_t kRightWheel = 1U;
constexpr size_t kLeftLegTorque = 2U;
constexpr size_t kRightLegTorque = 3U;

double MoveToward(double value, double target, double maximum_delta) {
    return value + std::clamp(target - value, -maximum_delta, maximum_delta);
}
}  // namespace

void JumpController::Reset() {
    phase_ = JumpPhase::kInit;
    phase_elapsed_s_ = 0.0;
    total_elapsed_s_ = 0.0;
    air_retract_hold_s_ = 0.0;
    theta_reference_ = {};
    yaw_reference_ = 0.0;
    retract_reference_ = {};
    airborne_controller_.Reset();
}

void JumpController::EnterPhase(JumpPhase phase,
                                const ChassisCycleInput &input) {
    phase_ = phase;
    phase_elapsed_s_ = 0.0;
    if (phase == JumpPhase::kAirRetract) {
        retract_reference_ = {input.leg.left.length, input.leg.right.length};
        air_retract_hold_s_ = 0.0;
    } else if (phase == JumpPhase::kAir) {
        airborne_controller_.Reset();
    }
}

void JumpController::ComputeAttitudeControl(
    const ChassisCycleInput &input, double actuator[kOutputCount]) const {
    double state_error[kStateCount] = {};
    const bool thrust = phase_ == JumpPhase::kThrust;
    // 本工程腿角零点为竖直方向，参考文档使用 pi/2。
    const double retract_theta_reference = -input.pitch;
    if (thrust) {
        state_error[2] = std::clamp(
            std::remainder(static_cast<double>(input.imu.yaw_deg) * kDegToRad -
                               yaw_reference_,
                           kTwoPi),
            -kYawTrackingErrorLimit, kYawTrackingErrorLimit);
        state_error[3] = input.imu.yaw_rate_rad_s;
        state_error[8] = input.pitch;
        state_error[9] = input.pitch_rate;
    }

    state_error[kLeftTheta] =
        input.theta.left -
        (thrust ? theta_reference_.left : retract_theta_reference);
    state_error[kLeftThetaRate] =
        input.theta_rate.left + (thrust ? 0.0 : input.pitch_rate);
    state_error[kRightTheta] =
        input.theta.right -
        (thrust ? theta_reference_.right : retract_theta_reference);
    state_error[kRightThetaRate] =
        input.theta_rate.right + (thrust ? 0.0 : input.pitch_rate);
    double gain[kOutputCount][kStateCount] = {};
    EvaluateUnifiedLqrGain(
        0.5 * (input.leg.left.length + input.leg.right.length), gain);
    for (size_t row = 0U; row < kOutputCount; ++row) {
        actuator[row] = 0.0;
        for (size_t column = 2U; column < kStateCount; ++column) {
            actuator[row] -= gain[row][column] * state_error[column];
        }
    }
}

void JumpController::ComputeVmcLeg(const ChassisCycleInput &input, Side side,
                                   double target_length, double target_rate,
                                   double support_force, double leg_torque,
                                   ChassisControlOutput &output) const {
    const LegKinematics &leg = input.leg.Get(side);
    const LegHardwareMap &hardware = config_.leg_hardware(side == Side::kRight);
    // 推力阶段仅通过 VMC 计算切向姿态力矩，不引入轴向阻尼。
    const LegVmcOutput vmc =
        ComputeLegVmc(leg, target_length, support_force, 0.0,
                      hardware.vmc_torque_sign * leg_torque,
                      phase_ == JumpPhase::kThrust ? 0.0 : leg.length_rate,
                      target_rate, config_);
    output.leg_axial_force.Get(side) = vmc.axial_force;
    output.body_on_leg_torque.Get(side) = leg_torque;
    JointPair<double> &torque = output.joint_torque.Get(side);
    torque.b = std::clamp(vmc.phi2_torque, -config_.joint_torque_limit,
                          config_.joint_torque_limit);
    torque.d = std::clamp(vmc.phi1_torque, -config_.joint_torque_limit,
                          config_.joint_torque_limit);
}

JumpControllerOutput JumpController::Update(const ChassisCycleInput &input,
                                            BalanceController &balance) {
    const double dt = std::clamp(input.dt, 0.0005, 0.01);
    if (phase_ == JumpPhase::kInit) {
        theta_reference_ = {input.theta.left, input.theta.right};
        yaw_reference_ = static_cast<double>(input.imu.yaw_deg) * kDegToRad;
        total_elapsed_s_ = 0.0;
        EnterPhase(JumpPhase::kPreCompress, input);
    }

    total_elapsed_s_ += dt;
    phase_elapsed_s_ += dt;
    JumpControllerOutput output = {};

    if (phase_ == JumpPhase::kPreCompress) {
        const double precompress_length = std::clamp(
            kJumpPrecompressLegLength, config_.min_commanded_leg_length,
            config_.max_commanded_leg_length);
        balance.set_target_leg_length(precompress_length);
        ChassisCycleInput precompress_input = input;
        precompress_input.remote.leg_length_delta = 0.0;
        balance.Update(precompress_input, output.control);
        const auto ready = [&](Side side) {
            const LegKinematics &leg = input.leg.Get(side);
            return std::abs(leg.length - precompress_length) <=
                       kJumpPrecompressLengthTolerance &&
                   std::abs(leg.length_rate) <= kJumpPrecompressSpeedTolerance;
        };
        if ((ready(Side::kLeft) && ready(Side::kRight)) ||
            phase_elapsed_s_ >=
                static_cast<double>(kJumpPrecompressTimeoutMs) * 0.001) {
            EnterPhase(JumpPhase::kThrust, input);
        }
    } else if (phase_ == JumpPhase::kThrust) {
        output.control.bypass_gas_spring_compensation = true;
        double actuator[kOutputCount] = {};
        ComputeAttitudeControl(input, actuator);
        output.control.physical_wheel_torque = {actuator[kLeftWheel],
                                                actuator[kRightWheel]};
        ComputeVmcLeg(input, Side::kLeft, input.leg.left.length, 0.0, 0.0,
                      actuator[kLeftLegTorque], output.control);
        ComputeVmcLeg(input, Side::kRight, input.leg.right.length, 0.0, 0.0,
                      actuator[kRightLegTorque], output.control);
        for (Side side : {Side::kLeft, Side::kRight}) {
            JointPair<double> &torque = output.control.joint_torque.Get(side);
            // 左右五连杆互为镜像，需在各自运动学分支应用配置的关节方向，
            // 使正跳跃力矩伸展双腿，而非只伸展左腿。
            const double mirror_sign = static_cast<double>(
                config_.leg_hardware(side == Side::kRight).kinematic_branch);
            torque.b = std::clamp(
                torque.b + mirror_sign * kJumpJointBThrustSign *
                               config_.jump_thrust_torque,
                -config_.joint_torque_limit, config_.joint_torque_limit);
            torque.d = std::clamp(
                torque.d + mirror_sign * kJumpJointDThrustSign *
                               config_.jump_thrust_torque,
                -config_.joint_torque_limit, config_.joint_torque_limit);
        }
        if (input.leg.left.length >= kJumpThrustExitLegLength &&
            input.leg.right.length >= kJumpThrustExitLegLength) {
            EnterPhase(JumpPhase::kAirRetract, input);
        } else if (phase_elapsed_s_ >=
                   static_cast<double>(kJumpThrustTimeoutMs) * 0.001) {
            EnterPhase(JumpPhase::kFailed, input);
        }
    } else if (phase_ == JumpPhase::kAirRetract) {
        double actuator[kOutputCount] = {};
        ComputeAttitudeControl(input, actuator);
        const double maximum_delta = kJumpAirRetractRate * dt;
        retract_reference_.left = MoveToward(
            retract_reference_.left, kJumpAirRetractLegLength, maximum_delta);
        retract_reference_.right = MoveToward(
            retract_reference_.right, kJumpAirRetractLegLength, maximum_delta);
        const double left_rate =
            retract_reference_.left > kJumpAirRetractLegLength
                ? -kJumpAirRetractRate
                : 0.0;
        const double right_rate =
            retract_reference_.right > kJumpAirRetractLegLength
                ? -kJumpAirRetractRate
                : 0.0;
        ComputeVmcLeg(input, Side::kLeft, retract_reference_.left, left_rate,
                      kJumpAirRetractGravityFeedforward,
                      actuator[kLeftLegTorque], output.control);
        ComputeVmcLeg(input, Side::kRight, retract_reference_.right, right_rate,
                      kJumpAirRetractGravityFeedforward,
                      actuator[kRightLegTorque], output.control);
        const bool retracted =
            std::abs(input.leg.left.length - kJumpAirRetractLegLength) <=
                kJumpAirRetractLengthTolerance &&
            std::abs(input.leg.right.length - kJumpAirRetractLegLength) <=
                kJumpAirRetractLengthTolerance &&
            std::abs(input.leg.left.length_rate) <=
                kJumpPrecompressSpeedTolerance &&
            std::abs(input.leg.right.length_rate) <=
                kJumpPrecompressSpeedTolerance;
        air_retract_hold_s_ = retracted ? air_retract_hold_s_ + dt : 0.0;
        if (air_retract_hold_s_ >=
            static_cast<double>(kJumpAirRetractHoldMs) * 0.001) {
            EnterPhase(JumpPhase::kAir, input);
        } else if (phase_elapsed_s_ >=
                   static_cast<double>(kJumpAirRetractTimeoutMs) * 0.001) {
            EnterPhase(JumpPhase::kFailed, input);
        }
    } else if (phase_ == JumpPhase::kAir) {
        const FlightControllerOutput airborne =
            airborne_controller_.Update(input);
        output.control = airborne.control;
        if (airborne.failed) {
            EnterPhase(JumpPhase::kFailed, input);
        } else if (airborne.finished) {
            EnterPhase(JumpPhase::kReturn, input);
        }
    }

    if (phase_ != JumpPhase::kReturn && phase_ != JumpPhase::kFailed &&
        total_elapsed_s_ >= static_cast<double>(kJumpTotalTimeoutMs) * 0.001) {
        EnterPhase(JumpPhase::kFailed, input);
    }

    output.phase = phase_;
    output.finished = phase_ == JumpPhase::kReturn;
    output.failed = phase_ == JumpPhase::kFailed;
    return output;
}
}  // namespace dust_control::chassis
